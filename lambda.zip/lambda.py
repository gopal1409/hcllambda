def lambda_handler(event,context):
    print("hello world from terraform - lambda fucntion")
    return "hello from terraform lambda"